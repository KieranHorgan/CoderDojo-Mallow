/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package InterfaceCallbacks;

/**
 *
 * @author TommieB
 */
public class MallowLooper {
    private ICallback cbLooper;
    public MallowLooper(ICallback cbLoopy){
        cbLooper = cbLoopy;
    }
    private void FireCallback(int iCbValue){
        if (cbLooper != null){
            cbLooper.cbProcessCount(iCbValue);
        }
    }
    public void LoopAround(){
        for (int i = 0; i < 20; i++){
            FireCallback(i);
        }
    }
}
