/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package InterfaceCallbacks;

/**
 *
 * @author TommieB
 */
public class MallowCbDemo implements ICallback{
    public MallowCbDemo(){ }
    public void Run(){
        MallowLooper md = new MallowLooper(this);
        md.LoopAround();
    }
    @Override
    public void cbProcessCount(int counter) {
        System.out.println("cbProcessCount: counter = " + counter);
    } 
}