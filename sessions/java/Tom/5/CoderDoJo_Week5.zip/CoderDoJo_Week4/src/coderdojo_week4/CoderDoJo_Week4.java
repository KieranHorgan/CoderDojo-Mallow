/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coderdojo_week4;

import Mallow4.Mallow4Pri;

/**
 *
 * @author TommieB
 */
public class CoderDoJo_Week4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Mallow4Pri primary = new Mallow4Pri();
        primary.Run();
    }
    
}
