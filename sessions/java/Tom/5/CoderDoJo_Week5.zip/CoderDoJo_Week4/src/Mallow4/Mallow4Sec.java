/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mallow4;

/**
 *
 * @author TommieB
 */
public class Mallow4Sec implements IMallow4{

    @Override
    public void cbMallow(int aNumber, String aString) {
        System.out.printf("[Mallow4Sec] - We got called back, aNumber = %d, aString = %s\n", aNumber, aString);
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
