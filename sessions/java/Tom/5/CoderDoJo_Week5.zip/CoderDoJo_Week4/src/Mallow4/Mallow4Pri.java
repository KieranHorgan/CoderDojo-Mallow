/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mallow4;

/**
 *
 * @author TommieB
 */
public class Mallow4Pri {
    private IMallow4 iMallowFour;
    public void Run(){
        iMallowFour = new Mallow4Sec();
        iMallowFour.cbMallow(123, "Hello World");
    }
}
