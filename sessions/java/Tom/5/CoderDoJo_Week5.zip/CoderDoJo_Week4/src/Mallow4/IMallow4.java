/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mallow4;

/**
 *
 * @author TommieB
 */
public interface IMallow4 {
    void cbMallow(int aNumber, String aString);
}
