/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MallowClass;

/**
 *
 * @author TommieB
 */

public class Mallow1 {
    
    private String vowels = "aeiou";
    private int noVowels = 0;
    private int noConsonants = 0;
    
    public Mallow1(){
        // Constructor - Applicable in other languages, C#, C++, PHP, Python, Javascript
        System.out.println("Mallow1 Constructor");
    }
    
    public int VowelCount(){
        return noVowels;
    }
    public int ConsonantCount(){
        return noConsonants;
    }
    private int countVowels(String source){
        int count = 0;
        for (int i = 0; i < source.length(); i++){
            char ch = source.charAt(i);
            if (Character.isLetter(ch) && vowels.indexOf(Character.toString(ch)) > 0){
                count += 1;
// count++; //Reminder - ask me about that! ;)
// count = count + 1;
            }
            
        }
        return count;
    }
    private int countConsonants(String source){
        int count = 0;
        for (int i = 0; i < source.length(); i++){
            char ch = source.charAt(i);
            if (Character.isLetter(ch) && vowels.indexOf(Character.toString(ch)) == -1){
                count += 1;
            }
        }
        return count;
    }
    public String ConvertToUpper(String source){
        noVowels = countVowels(source);
        noConsonants = countConsonants(source);
        return source.toUpperCase();
    }
}
