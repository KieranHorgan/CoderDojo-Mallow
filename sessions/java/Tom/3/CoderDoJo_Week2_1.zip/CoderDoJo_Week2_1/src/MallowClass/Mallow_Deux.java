/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MallowClass;

/**
 *
 * @author TommieB
 */
public class Mallow_Deux extends Mallow1{
    // To be continued
    public int CountWords(String source){
        if (source == null || source.length() == 0){
            throw new IllegalArgumentException("source is either null or empty");
        }
        //String[] strArray = source.split(" ");
        //return strArray.length
        return source.split(" ").length;
    }
}
