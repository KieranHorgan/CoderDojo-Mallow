/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coderdojo_week2;

import MallowClass.*;

/**
 *
 * @author TommieB
 */
public class CoderDoJo_Week2 {

    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Mallow_Deux mallow = new Mallow_Deux();
        String sHelloWorld = "Hello World";
        System.out.println("Length of string = " + sHelloWorld.length());
        String sRetVal = mallow.ConvertToUpper(sHelloWorld);
        System.out.println("Result = " + sRetVal);
        System.out.println("Count of vowels = " + mallow.VowelCount());
        System.out.println("Count of consonants = " + mallow.ConsonantCount());
        try{
            System.out.println("Count of words = " + mallow.CountWords(null));
        }catch(Exception ex){
            System.out.println("Whoops! Error = " + ex);
        }
        
    }
    
}
