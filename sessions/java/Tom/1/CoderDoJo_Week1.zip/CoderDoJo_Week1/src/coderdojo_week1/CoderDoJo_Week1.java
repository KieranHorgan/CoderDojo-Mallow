/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coderdojo_week1;

import bloocoob.BlueCube;


/**
 *
 * @author TommieB
 */
public class CoderDoJo_Week1 {

    // { } curly brackets
    // [ ] square brackets
    // ( ) parenthesis
    
    private static int MAX_LOOP;
    private static String CLASS_ID = "CoderDoJo_Week1";
    public static int AddUp(int x, int y){
        return x + y;
    }
    
    public static void AddUpTwo(int x, int y){
        System.out.println(x + y);
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        MAX_LOOP = 5;
        // for (start; condition; end){... block... }
        for (int i = 0; i < MAX_LOOP; i++){
            System.out.println("Hello " + i);
        }
        // do { .. block .. } while (condition);
        int i = 0;
        do{
            System.out.println("World " + i);
            i = i + 1;
        }while (i < MAX_LOOP);
        i = 0;
        // while (condition){ ... block ... }
        while (i < MAX_LOOP){
            System.out.println("Hello World " + i);
            i = i + 1;
        }
        //
        int result = AddUp(1, 1);
        System.out.println("Result = " + result);
        
        AddUpTwo(1, 1);
        // Instantiate a new class.
        BlueCube bc = new BlueCube();
        System.out.println(bc.AddUp(1, 2));
        //
        bc.AddUpTwo(1, 2);
    }
    
}
