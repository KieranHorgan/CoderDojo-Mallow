/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bloocoob;

/**
 * Simple demo class that does nothing more than add two numbers
 * @author TommieB
 */
public class BlueCube {
    private String CLASS_ID = "BlueCube";
    /**
     * Empty constructor
     */
    public BlueCube(){}
    /**
     * Simple function to add two numbers
     * @param x integer
     * @param y integer
     * @return sum of x and y
     */
    public int AddUp(int x, int y){
        String sOutputMsg = String.format("%s:AddUp(%d, %d)", CLASS_ID, x, y);
        System.out.println(sOutputMsg);
        return x+ y;
    }
    
    /**
     * Simple method to output two numbers
     * @param x integer
     * @param y integer
     */
    public void AddUpTwo(int x, int y){
        System.out.format("%s:AddUpTwo(%d,%d)\n", CLASS_ID, x, y, x+y);
    }
}
